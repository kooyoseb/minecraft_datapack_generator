import tkinter as tk
from tkinter import filedialog, messagebox
import os
import json

def save_datapack():
    minecraft_version = version_var.get()
    pack_name = pack_name_entry.get()
    namespace = namespace_entry.get()
    description = description_text.get("1.0", tk.END).strip()

    if not pack_name or not namespace:
        messagebox.showerror("오류", "팩 이름과 네임스페이스는 필수 입력 항목입니다.")
        return

    datapack_dir = filedialog.askdirectory(title="데이터팩을 저장할 폴더 선택")
    if not datapack_dir:
        return

    datapack_path = os.path.join(datapack_dir, pack_name)
    try:
        os.makedirs(datapack_path)

        # Create pack.mcmeta
        pack_mcmeta = {
            "pack": {
                "pack_format": version_pack_format(minecraft_version),
                "description": description
            }
        }

        with open(os.path.join(datapack_path, "pack.mcmeta"), "w", encoding="utf-8") as f:
            json.dump(pack_mcmeta, f, indent=4, ensure_ascii=False)

        # Create data folder structure
        data_folder = os.path.join(datapack_path, "data", namespace)
        os.makedirs(os.path.join(data_folder, "functions"))
        messagebox.showinfo("성공", f"데이터팩 '{pack_name}' 생성이 완료되었습니다.")
    except Exception as e:
        messagebox.showerror("오류", f"데이터팩 생성에 실패했습니다: {e}")

def version_pack_format(version):
    version_map = {
        "1.16": 6,
        "1.17": 7,
        "1.18": 8,
        "1.19": 9,
        "1.20": 10,
        "1.21": 11,
        "1.21.4": 12,
        "1.22": 13
    }
    return version_map.get(version, 0)

def change_language(language):
    if language == "한국어":
        root.title("마인크래프트 데이터팩 생성기")
        version_label.config(text="마인크래프트 버전:")
        pack_name_label.config(text="데이터팩 이름:")
        namespace_label.config(text="네임스페이스:")
        description_label.config(text="설명:")
        save_button.config(text="데이터팩 생성")
        language_menu_button.config(text="언어")
    elif language == "English":
        root.title("Minecraft Datapack Generator")
        version_label.config(text="Minecraft Version:")
        pack_name_label.config(text="Datapack Name:")
        namespace_label.config(text="Namespace:")
        description_label.config(text="Description:")
        save_button.config(text="Generate Datapack")
        language_menu_button.config(text="Language")

# GUI Setup
root = tk.Tk()
root.title("마인크래프트 데이터팩 생성기")

# Labels and Inputs
version_label = tk.Label(root, text="마인크래프트 버전:")
version_label.grid(row=0, column=0, padx=10, pady=5, sticky="e")

version_var = tk.StringVar(value="1.21.4")
version_menu = tk.OptionMenu(root, version_var, "1.16", "1.17", "1.18", "1.19", "1.20", "1.21", "1.21.4", "1.22")
version_menu.grid(row=0, column=1, padx=10, pady=5, sticky="w")

pack_name_label = tk.Label(root, text="데이터팩 이름:")
pack_name_label.grid(row=1, column=0, padx=10, pady=5, sticky="e")

pack_name_entry = tk.Entry(root)
pack_name_entry.grid(row=1, column=1, padx=10, pady=5, sticky="w")

namespace_label = tk.Label(root, text="네임스페이스:")
namespace_label.grid(row=2, column=0, padx=10, pady=5, sticky="e")

namespace_entry = tk.Entry(root)
namespace_entry.grid(row=2, column=1, padx=10, pady=5, sticky="w")

description_label = tk.Label(root, text="설명:")
description_label.grid(row=3, column=0, padx=10, pady=5, sticky="ne")

description_text = tk.Text(root, height=4, width=30)
description_text.grid(row=3, column=1, padx=10, pady=5, sticky="w")

# Language Menu
language_menu_button = tk.Menubutton(root, text="언어", relief=tk.RAISED)
language_menu = tk.Menu(language_menu_button, tearoff=0)
language_menu.add_command(label="한국어", command=lambda: change_language("한국어"))
language_menu.add_command(label="English", command=lambda: change_language("English"))
language_menu_button.config(menu=language_menu)
language_menu_button.grid(row=4, column=0, padx=10, pady=5, sticky="w")

# Buttons
save_button = tk.Button(root, text="데이터팩 생성", command=save_datapack)
save_button.grid(row=5, column=0, columnspan=2, pady=10)

# Version Label
version_info = tk.Label(root, text="버전: 1.5", anchor="e")
version_info.grid(row=6, column=0, columnspan=2, pady=5, sticky="e")

root.mainloop()
